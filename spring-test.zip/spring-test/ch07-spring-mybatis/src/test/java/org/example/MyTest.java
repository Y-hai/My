package org.example;

import org.example.dao.StudentDao;
import org.example.domain.Student;
import org.example.service.StudentService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MyTest {

    @Test
    public void test01() {
        String config = "applicationContext.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        String[] names = ctx.getBeanDefinitionNames();
        for (String name : names) {
            System.out.println(name + " | " + ctx.getBean(name));
        }
    }

    @Test
    public void test02() {
        String config = "applicationContext.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        // 获取dao对象
        StudentDao dao = (StudentDao) ctx.getBean("studentDao");
        Student student = new Student();
        student.setId(1008);
        student.setName("zzm");
        student.setEmail("zzm@qq.com");
        student.setAge(20);
        int num = dao.insertStudent(student);
        System.out.println(num);
    }

    @Test
    public void test03() {
        String config = "applicationContext.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        // 获取service对象
        StudentService service = (StudentService) ctx.getBean("studentService");
        Student student = new Student();
        student.setId(1009);
        student.setName("qzm");
        student.setEmail("qzm@qq.com");
        student.setAge(25);
        int num = service.addStudent(student);
        // spring和mybatis整合在一起时，事务是自动提交的
        System.out.println(num);
    }

    @Test
    public void test04() {
        String config = "applicationContext.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        // 获取service对象
        StudentService service = (StudentService) ctx.getBean("studentService");
        List<Student> students = service.queryStudents();
        // spring和mybatis整合在一起时，事务是自动提交的
        students.forEach(student -> System.out.println(students));
    }
}
