package org.example.controller;

import org.example.domain.Student;
import org.example.service.StudentService;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String strId = request.getParameter("id");
        String strName = request.getParameter("name");
        String strEmail = request.getParameter("email");
        String strAge = request.getParameter("age");

        // 创建spring的容器对象
//        String config = "applicationContext.xml";
//        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        WebApplicationContext ctx = null;
        // 获取ServletContext中的容器对象,创建好的容器对象
//        String key = WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE;
//        Object attr = getServletContext().getAttribute(key);
//        if (attr != null) {
//            ctx = (WebApplicationContext) attr;
//        }
        // 使用框架中的方法获取容器对象
        ServletContext sc = getServletContext();
        ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(sc);
        /**
         * 容器对象的信息:
         * org.springframework.context.support.ClassPathXmlApplicationContext@527f58c5,
         * started on Thu Jan 27 22:31:43 CST 2022
         * 容器对象的信息:Root WebApplicationContext,
         * started on Thu Jan 27 22:57:37 CST 2022
         * 容器对象的信息:Root WebApplicationContext,
         * started on Thu Jan 27 22:57:37 CST 2022
         */
        System.out.println("容器对象的信息:" + ctx);

        // 获取service
        StudentService service = (StudentService) ctx.getBean("studentService");
        Student student = new Student();
        student.setId(Integer.parseInt(strId)); // 用parseInt
        student.setName(strName);
        student.setEmail(strEmail);
        student.setAge(Integer.valueOf(strAge));
        service.addStudent(student);
        // 转发
        request.getRequestDispatcher("/result.jsp").forward(request, response);
    }
}
