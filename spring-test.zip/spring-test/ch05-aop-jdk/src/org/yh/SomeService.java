package org.yh;

public interface SomeService {
    void doSome(int a);
    void doOther();
}
