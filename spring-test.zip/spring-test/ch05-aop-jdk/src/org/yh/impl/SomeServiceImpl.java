package org.yh.impl;

import org.yh.SomeService;

public class SomeServiceImpl implements SomeService {
    @Override
    public void doSome(int a) {
        int b = a;
        System.out.println("业务方法doSome执行了：" + b);
    }

    @Override
    public void doOther() {
        System.out.println("业务方法doOther执行了");
    }
}
