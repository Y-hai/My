package org.handler;

import org.util.ServiceTools;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MyIncationHandler implements InvocationHandler {
    private Object target;

    public MyIncationHandler(Object target) {
        this.target = target;
    }

    /**
     * @param proxy：刚才JDK动态生成的对象
     * @param method：接口中的目标方法     (被调用的doSome)
     * @param args：传进接口中目标方法的实参列表 (eg:doSome的Integer参数)
     * @return
     * @throws Throwable
     */
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("执行了MyIncationHandler中的invoke()方法");
        Object res = null;
        // 动态代理控制增强哪些方法，AOP底层就是动态代理
        String className = method.getName();
        if ("doSome".equals(className)) {
            ServiceTools.doLog();
            res = method.invoke(target, args);
            ServiceTools.doTrans();
        } else {
            res = method.invoke(target, args);
        }
        return res;
    }
}
