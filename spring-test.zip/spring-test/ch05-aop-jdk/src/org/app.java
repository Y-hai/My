package org;

import org.handler.MyIncationHandler;
import org.yh.SomeService;
import org.yh.impl.SomeServiceImpl;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

public class app {
    public static void main(String[] args) {
        // 创建目标对象
        SomeService target = new SomeServiceImpl();
        // 创建Handler对象
        InvocationHandler handler = new MyIncationHandler(target);
        // 创建代理对象，代理类由JVM生成
        SomeService proxy = (SomeService) Proxy.newProxyInstance(
                target.getClass().getClassLoader(),// 类加载器
                target.getClass().getInterfaces(),// 目标对象实现的接口列表，字节码文件中的interface表
                handler);
        proxy.doSome(2); // 执行handler对象中的invoke()方法，有返回值但这里不用接收
        System.out.println("===================================================");
        proxy.doOther();
    }
}
