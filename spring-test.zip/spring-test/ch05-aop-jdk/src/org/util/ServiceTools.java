package org.util;

import java.util.Date;

public class ServiceTools {

    public static void doLog() {
        System.out.println("非业务方法，方法的执行时间：" + new Date());
    }

    public static void doTrans() {
        //提交事务
        System.out.println("方法执行完毕，提交事务");
    }
}
