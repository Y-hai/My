package org.example.dao;

import org.example.domain.Goods;

public interface GoodsDao {
    // 更新库存
    // goods表示本次购买的商品信息
    int updateGoods(Goods goods);

    // 获取商品的信息
    Goods selectGoods(Integer id);
}
