package org.example.service;

public interface BuyGoodsService {

    // 购买商品的方法
    void buy(Integer goodsId, Integer nums);
}
