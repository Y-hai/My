package org.example;

import org.example.ba02.SomeService;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test02 {
    @Test
    public void test01() {
        String config = "applicationContext.xml";
        ApplicationContext ctx = new ClassPathXmlApplicationContext(config);
        // 从容器中获取目标对象，JDK动态生成
        SomeService proxy = (SomeService) ctx.getBean("someService");
//        System.out.println("proxy:" + proxy.getClass().getName());
//        代理类的名字：com.sun.proxy.$Proxy8
        // 通过代理的对象执行方法，实现目标方法执行时，增强了功能
        String str = proxy.doOther("zhangsan", 28);
        System.out.println("测试方法中的：" + str);
    }
}
