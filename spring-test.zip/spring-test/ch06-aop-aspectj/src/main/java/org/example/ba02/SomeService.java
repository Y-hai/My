package org.example.ba02;

public interface SomeService {
    void doSome(String name, Integer age);
    String doOther(String name, Integer age);
}
