package org.example.ba06;

// 目标类
public class SomeServiceImpl implements SomeService {

    // 目标方法
    @Override
    public void doSome(String name, Integer age) {
        System.out.println("目标方法doSome已执行" + name + " " + age);
    }

    @Override
    public String doOther(String name, Integer age) {
        System.out.println("目标方法doOther已执行" + name + " " + age);
        return "abc";
    }

    @Override
    public String doFirst(String name, Integer age) {
        System.out.println("====业务方法doFirst()=====");
        return "doFirst";
    }

    @Override
    public void doSecond() {
        System.out.println("======执行业务方法doSecond()=======" + 10 / 0);
    }

    @Override
    public void doThird() {
        System.out.println("====业务方法doThird()=====");
    }
}
