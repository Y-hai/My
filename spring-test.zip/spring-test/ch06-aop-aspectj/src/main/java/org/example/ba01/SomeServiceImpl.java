package org.example.ba01;

// 目标类
public class SomeServiceImpl implements SomeService {
    // 目标方法
    @Override
    public void doSome(String name, Integer age) {
        System.out.println("目标方法doSome已执行" + name + " " + age);
    }
}
