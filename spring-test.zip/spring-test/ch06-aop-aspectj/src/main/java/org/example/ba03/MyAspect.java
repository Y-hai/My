package org.example.ba03;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import java.util.Date;

/**
 * @Aspect:是aspectj框架中的注解。 作用：表示当前类是切面类
 * 切面类：是用来给切面方法增加功能的类，在这个类中有切面的功能代码
 * 位置：在类定义的上面
 */
@Aspect
public class MyAspect {
    /**
     * 环绕通知定义方法，方法是实现切面功能的
     * 方法的定义要求：
     * 1.公共方法public
     * 2.必须有返回值，推荐使用Object
     * 3.方法名称自定义
     * 4.方法有参数，推荐使用Object，参数名ProceedingJoinPoint
     */
    /**
     * @Around：环绕通知 属性：value 切点表达式
     * 位置：在方法定义上面
     * 特点：
     * 1.它是功能最强的一个通知
     * 2.它可以在目标方法的前和后都可以增强功能
     * 3.控制目标方法是否被调用执行
     * 4.修改原来的目标方法的执行结果，影响最后的调用结果
     * <p>
     * 环绕通知，等同于jdk动态代理的，InvocationHandler接口
     * <p>
     * 参数：ProceedingJoinPoint就等同于JDK动态代理里的Method
     * 作用：执行目标方法的
     * 返回值：就是目标方法的执行结果，可以被修改
     *
     * 环绕通知：经常做事务，在目标方法前开启事务，在目标方法后提交事务（或者回滚）
     */
    @Around(value = "execution(* *..SomeServiceImpl.doFirst(..))")
    public Object myAround(ProceedingJoinPoint pjp) throws Throwable {
        // 获取第一个参数值
        String name = ""; // 不建议初始化为null
        Object[] args = pjp.getArgs();
        if (args != null && args.length > 1) {
            Object arg = args[0];
            name = (String) arg;
        }
        // 实现环绕通知
        Object result = null;
        System.out.println("环绕通知：在目标方法之前，输出时间：" + new Date());
        // 1.目标方法的调用，围绕着这个业务方法加通知
        if ("张飞".equals(name)) { // 通常把已知字符串放前面，这样可以防止空指针异常
            // 符合条件，调用目标方法
            result = pjp.proceed(); // 等同于method.invoke()
        }
        // 2.目标方法的增强，在前面也行
        System.out.println("环绕通知：在目标方法之后，提交事务");
        // 3.返回目标方法的执行结果
        if (result != null) result = "Hello AspectJ!";
        return result;
    }

}
