package org.example.ba06;

public interface SomeService {
    void doSome(String name, Integer age);

    String doOther(String name, Integer age);

    String doFirst(String name, Integer age);

    void doSecond();

    void doThird();
}
