package org.example.ba09;

public class test {
    // 模拟ba02中的例子
    public static void main(String[] args) {
        example e = new example();
        String str = "Hello ";
        e.sss(str);
        System.out.println(str);
    }
}
