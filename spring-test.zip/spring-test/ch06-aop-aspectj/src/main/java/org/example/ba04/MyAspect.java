package org.example.ba04;

import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;

/**
 * @Aspect:是aspectj框架中的注解。 作用：表示当前类是切面类
 * 切面类：是用来给切面方法增加功能的类，在这个类中有切面的功能代码
 * 位置：在类定义的上面
 */
@Aspect
public class MyAspect {
    /**
     * 异常通知方法定义，方法是实现切面功能的
     * 方法的定义要求：
     * 1.公共方法public
     * 2.无返回值
     * 3.方法名称自定义
     * 4.方法有一个Exception参数，JoinPoint参数可选
     */
    /**
     * @AfterThrowing:异常通知 属性：
     * 1.value 切入点表达式
     * 2.throwing 自定义的变量，表示目标方法抛出的异常对象，变量名必须和方法的参数名一样
     * 特点：
     * 1.在目标方法抛出异常时执行
     * 2.可以做异常的监控程序，监控目标方法执行时是不是有异常。
     * 如果有异常，可以发送邮件，短信来进行通知
     */
    @AfterThrowing(value = "execution(* *..SomeServiceImpl.doSecond(..))",
            throwing = "ex")
    public void myAfterThrowing(Exception ex) {
        System.out.println("异常通知：方法发生异常时执行：" + ex.getMessage());
        // 发送邮件、短信
    }
}
