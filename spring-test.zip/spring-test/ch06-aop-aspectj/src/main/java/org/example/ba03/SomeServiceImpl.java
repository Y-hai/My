package org.example.ba03;

// 目标类
public class SomeServiceImpl implements SomeService {
    // 目标方法
    @Override
    public void doSome(String name, Integer age) {
        System.out.println("目标方法doSome已执行" + name + " " + age);
    }

    @Override
    public String doOther(String name, Integer age) {
        System.out.println("目标方法doOther已执行" + name + " " + age);
        return "abc";
    }

    @Override
    public String doFirst(String name, Integer age) {
        System.out.println("====业务方法doFirst()=====");
        return "doFirst";
    }
}
