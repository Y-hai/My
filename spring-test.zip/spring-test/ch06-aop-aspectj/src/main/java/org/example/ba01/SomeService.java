package org.example.ba01;

public interface SomeService {
    void doSome(String name, Integer age);
}
