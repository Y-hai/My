package org.example.ba09;

public class example {
    public void sss(String str){
        System.out.println(str);
        str = "aaaa";
        System.out.println(str);
    }
}
