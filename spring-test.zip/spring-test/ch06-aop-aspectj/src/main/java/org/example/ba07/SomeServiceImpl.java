package org.example.ba07;

// 目标类
public class SomeServiceImpl {

    // 目标方法
    public void doThird() {
        System.out.println("====业务方法doThird()=====");
    }
}
