### 使用IOC，由Spring创建对象

实现步骤

- 创建Maven项目
- 加入Maven的依赖
    - Spring依赖
    - junit依赖
- 创建类（接口和它的实现类）
- 创建Spring需要使用的配置文件 声明类的信息，这些类由Spring创建和管理
- 测试Spring创建的对象