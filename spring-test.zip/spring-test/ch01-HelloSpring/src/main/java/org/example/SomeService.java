package org.example;

public interface SomeService {
    void dosome();
}
